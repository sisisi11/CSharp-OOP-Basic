﻿using System;
using System.Collections.Generic;
using System.Linq;


public class Family
{
    private List<Person> people = new List<Person>();

    public List<Person> People
    {
        get { return this.people; }
        set { this.people = value; }
    }

    public void AddMember(Person member)
    {
        this.People.Add(member);
    }

    public Person GetOldestMember()
    {
        return this.People.OrderByDescending(x => x.Age).First();
    }

}