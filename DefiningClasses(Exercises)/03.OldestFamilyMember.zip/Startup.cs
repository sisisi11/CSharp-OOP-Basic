﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

class Startup
{
    static void Main()
    {
        MethodInfo oldestMemberMethod = typeof(Family).GetMethod("GetOldestMember");
        MethodInfo addMemberMethod = typeof(Family).GetMethod("AddMember");
        if (oldestMemberMethod == null || addMemberMethod == null)
        {
            throw new Exception();
        }
        int n = int.Parse(Console.ReadLine());

        var family = new Family();
        for (int i = 0; i < n; i++)
        {
            var inputLine = Console.ReadLine().Split(' ');
            var personName = inputLine[0];
            var personAge = int.Parse(inputLine[1]);

            var person = new Person(personName, personAge);
            family.AddMember(person);
        }
        Person oldest = family.GetOldestMember();
        Console.WriteLine($"{string.Join("", oldest.Name)} {oldest.Age}");
    }
}