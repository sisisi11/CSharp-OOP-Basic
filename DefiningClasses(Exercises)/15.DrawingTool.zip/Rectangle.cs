﻿using System;

public class Rectangle : Figure
{
    public Rectangle(int width, int height)
        : base(width, height)
    {
    }
}