﻿using System;

public class Square : Figure
{
    public Square(int size)
        : base(size, size)
    {
    }
}