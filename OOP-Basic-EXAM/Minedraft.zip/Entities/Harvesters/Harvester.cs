﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public abstract class Harvester
{
    private string id;
    private double oreOutput;
    private double energyRequirement;

    public Harvester(string id, double oreOutput, double energyRequirement)
    {
        this.id = id;
        this.oreOutput = oreOutput;
        this.energyRequirement = energyRequirement;
    }


    public double OreOutput
    {
        get
        {
            return this.oreOutput;
        }
        set
        {
            if (value < 0)
            {
                throw new ArgumentException();
            }
            this.oreOutput = value;
        }
    }
    public double EnergyRequirement
    {
        get
        {
            return this.energyRequirement;
        }
        set
        {
            if (value < 0 || value > 20000)
            {
                throw new ArgumentException();
            }
            this.energyRequirement = value;
        }
    }
}