﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public abstract class Bender
{
    private string name;
    private uint power;

    protected Bender(string name, uint power)
    {
        this.name = name;
        this.power = power;
    }

    public uint Power { get { return this.power; } set { this.power = value; } }

    public override string ToString()
    {
        return $"{this.GetType().Name.Replace("Bender", string.Empty)} Bender: {this.name}, Power: {this.power}";
    }
}